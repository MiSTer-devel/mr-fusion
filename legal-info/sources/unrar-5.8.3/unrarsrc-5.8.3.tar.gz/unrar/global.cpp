#define INCLUDEGLOBAL

#if defined(__BORLANDC__) || defined(_MSC_VER)
#pragma hdrstop
#endif

#include "rar.hpp"
